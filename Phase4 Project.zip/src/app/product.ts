export class Product {
     product_id:number;	
	 product_name:string;
	 price:number;
	 brand: string;
	 color: string;	
	 image:string;
}
