import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-delete-product',
  templateUrl: './delete-product.component.html',
  styleUrls: ['./delete-product.component.css']
})
export class DeleteProductComponent implements OnInit {
 
  // product:Product;
  id: number;
  //  product_id:number;
  constructor(private productservice:ProductService, private router:Router) { 
    //  this.product=new Product();
    
    
  }
  public deleteProduct():void{
    this.productservice.deleteProductById(this.id).subscribe(res=>{
      //  this.product=new Product();
      // this.product_id=null;
      this.router.navigate(['/productsList']);
      
    })
  }
  ngOnInit() {
  }

}
