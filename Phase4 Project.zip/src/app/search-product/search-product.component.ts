import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';
import { Product } from '../product';

@Component({
  selector: 'app-search-product',
  templateUrl: './search-product.component.html',
  styleUrls: ['./search-product.component.css']
})
export class SearchProductComponent implements OnInit {

  // ProductList:Product[]=[];
  id: number;
  target:Product;
  ProductTable:boolean=false;

  constructor(private productservice:ProductService, private router:Router) {
    
    
   }

   public searchProduct(){
    this.productservice.getProductById(this.id).subscribe(res=>{
      this.target=res;
      
      if(this.target!=null)
      {
        this.ProductTable=true;
      }
      
    })
  }

  ngOnInit() {
    
  }

}
