import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddProductComponent } from './add-product/add-product.component';
import { DeleteProductComponent } from './delete-product/delete-product.component';
import { SearchProductComponent } from './search-product/search-product.component';
import { UpdateProductComponent } from './update-product/update-product.component';
import { ProductsListComponent } from './products-list/products-list.component';


const routes: Routes = [
  {path:'addProduct',component:AddProductComponent},
  {path:'deleteProduct',component:DeleteProductComponent},
  {path:'updateProduct',component:UpdateProductComponent},
  {path:'searchProduct',component:SearchProductComponent},
  {path:'productsList',component:ProductsListComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
